chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.target !== 'offscreen') return;
  if (request.type === 'copy') {
    const sandbox = document.getElementById('sandbox');
    sandbox.value = '';
    sandbox.focus();
    const pasted = document.execCommand('paste');
    sendResponse(sandbox.value.trim());
    return true;
  }
});
